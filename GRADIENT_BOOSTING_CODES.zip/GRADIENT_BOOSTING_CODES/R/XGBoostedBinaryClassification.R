pneumonia.data<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/pneumonia_data.csv", 
header=TRUE, sep=",")

pneumonia.data$pneumonia<- ifelse(pneumonia.data$pneumonia=="yes",1,0)

#SPLITTING DATA INTO 80% TRAINING AND 20% TESTING SETS 
set.seed(447558)
library(caret)
sample<- createDataPartition(pneumonia.data$pneumonia, p=0.8, list=FALSE)
train<- pneumonia.data[sample,]
test<- pneumonia.data[-sample,]

train.x<- data.matrix(train[, names(train)!= "pneumonia"])
train.y<- train$pneumonia
test.x<- data.matrix(test[, names(test)!= "pneumonia"])
test.y<- test$pneumonia

#FITTING GRADIENT BOOSTED BINARY CLASSIFIER
dtrain<- xgb.DMatrix(data=train.x, label=train.y)

library(xgboost)
xgb.class<- xgb.train(data=dtrain, params=list(max_depth=6, eta=0.1,
objective="binary:logistic"), nrounds=1000) #eta=learning rate, nrounds=no. of trees

#DISPLAYING FEATURE IMPORTANCE
print(xgb.importance(colnames(train.x), model=xgb.class))

#PREDICTING FOR TESTING SET
pred.prob<- predict(xgb.class, test.x)

#COMPUTING ACCURACY OF PREDICTION 
len<- length(pred.prob)
pred.pneumonia<- c()
match<- c()
for (i in 1:len){
  pred.pneumonia[i]<- ifelse(pred.prob[i]>=0.5, 1,0)
  match[i]<- ifelse(test.y[i]==pred.pneumonia[i], 1,0)
}
print(prop<- sum(match)/len)


