movie.data<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/movie_data.csv",
header=TRUE, sep=",")

movie.data$target<- ifelse(movie.data$rating=="very bad",0,ifelse
(movie.data$rating=="bad",1,ifelse(movie.data$rating=="okay",2,
ifelse(movie.data$rating=="good",3,4))))
movie.data<- subset(movie.data, select=-rating)

#SPLITTING DATA INTO 80% TRAINING AND 20% TESTING SETS 
set.seed(103321)
library(caret)
sample<- createDataPartition(movie.data$target, p=0.8, list=FALSE)
train<- movie.data[sample,]
test<- movie.data[-sample,]

train.x<- data.matrix(train[-5])
train.y<- data.matrix(train[5])
test.x<- data.matrix(test[-5])
test.y<- data.matrix(test[5])

#FITTING GRADIENT BOOSTED MULTINOMIAL CLASSIFIER
dtrain<- xgb.DMatrix(data=train.x, label=train.y)

library(xgboost)
xgb.mclass<- xgb.train(data=dtrain, params=list(num_class=5,
max_depth=6, eta=0.1, objective="multi:softprob"), nrounds=1000)

#DISPLAYING FEATURE IMPORTANCE
print(xgb.importance(colnames(train.x), model=xgb.mclass))

#PREDICTING FOR TESTING SET
pred.prob<- predict(xgb.mclass, test.x)
pred.class<- max.col(pred.prob)-1

#COMPUTING ACCURACY OF PREDICTION 
accuracy<- mean(pred.class==test.y)
print(accuracy)