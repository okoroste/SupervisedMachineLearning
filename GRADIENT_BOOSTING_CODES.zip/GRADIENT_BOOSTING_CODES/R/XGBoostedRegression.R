housing.data<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/housing_data.csv", 
header=TRUE, sep=",")

#SPLITTING DATA INTO 80% TRAINING AND 20% TESTING SETS 
set.seed(9000345)
library(caret)
sample<- createDataPartition(housing.data$housing_median_age, p=0.8, list=FALSE)
train<- housing.data[sample,]
test<- housing.data[-sample,]

train.x<- data.matrix(train[-8])
train.y<- train[[8]]          #numeric vector
test.x<- data.matrix(test[-8])
test.y<- test[[8]]          

#FITTING GRADIENT BOOSTED REGRESSION
library(xgboost)
xgb.reg<- xgboost(train.x, train.y, max_depth=6, learning_rate=0.1, nrounds=1000,
objective="reg:squarederror") #nrounds=no. of trees

#DISPLAYING FEATURE IMPORTANCE
print(xgb.importance(feature_names=colnames(train.x), model=xgb.reg))

#PREDICTING FOR TESTING SET
pred.y<- predict(xgb.reg, test.x)

#COMPUTING ACCURACY OF PREDICTION 
accuracy10<- ifelse(abs(test.y-pred.y)<0.10*test.y, 1, 0)
print(mean(accuracy10))

accuracy15<- ifelse(abs(test.y-pred.y)<0.15*test.y, 1, 0)
print(mean(accuracy15))

accuracy20<- ifelse(abs(test.y-pred.y)<0.20*test.y, 1, 0)
print(mean(accuracy20))

