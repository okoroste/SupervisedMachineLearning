pneumonia.data<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/pneumonia_data.csv", 
header=TRUE, sep=",")

pneumonia.data$pneumonia<- relevel(as.factor(pneumonia.data$pneumonia), ref="no")
pneumonia.data$gender<- ifelse(pneumonia.data$gender=='M',1,0)
pneumonia.data$tobacco_use<- ifelse(pneumonia.data$tobacco_use=='yes',1,0) 

#SPLITTING DATA INTO 80% TRAINING AND 20% TESTING SETS 
set.seed(503548)
library(caret)
sample<- createDataPartition(pneumonia.data$pneumonia, p=0.8, list=FALSE)
train<- pneumonia.data[sample,]
test<- pneumonia.data[-sample,]

test.x<- data.matrix(test[-5])
test.y<- data.matrix(test[5])

library(neuralnet)

#FITTING ANN WITH LOGISTIC ACTIVATION FUNCTION AND ONE LAYER WITH THREE NEURONS
ann.log.class<- neuralnet(as.factor(pneumonia) ~ gender + age + tobacco_use + PM2_5, 
data=train, hidden=3, act.fct="logistic", stepmax=1e7)

#PLOTTING THE DIAGRAM
plot(ann.log.class)

#COMPUTING PREDICTION ACCURACY FOR TESTING DATA
pred.prob<- predict(ann.log.class, test.x)[,1]
pred.y<- ifelse(pred.prob>0.5, 1, 0)
print(paste("accuracy =", round(mean(pred.y==test.y), 4)))


####################################################################
#FITTING ANN WITH LOGISTIC ACTIVATION FUNCTION AND C(2,3) LAYERS
ann.log23.class<- neuralnet(as.factor(pneumonia) ~ gender + age + tobacco_use + PM2_5, 
data=train, hidden=c(2,3), act.fct="logistic", stepmax=1e7)

#PLOTTING THE DIAGRAM
plot(ann.log23.class)

#COMPUTING PREDICTION ACCURACY FOR TESTING DATA
pred.prob<- predict(ann.log23.class, test.x)[,1]
pred.y<- ifelse(pred.prob>0.5, 1, 0)
print(paste("accuracy =", round(mean(pred.y==test.y), 4)))

####################################################################
#FITTING ANN WITH TANH ACTIVATION FUNCTION
ann.tanh.class<- neuralnet(as.factor(pneumonia) ~ gender + age + tobacco_use + PM2_5, 
data=train, hidden=3, act.fct="tanh", stepmax=1e7)

#PLOTTING THE DIAGRAM
plot(ann.tanh.class)

#COMPUTING PREDICTION ACCURACY FOR TESTING DATA
pred.prob<- predict(ann.tanh.class, test.x)[,1]
pred.y<- ifelse(pred.prob>0.5, 1, 0)
print(paste("accuracy =", round(mean(pred.y==test.y), 4)))