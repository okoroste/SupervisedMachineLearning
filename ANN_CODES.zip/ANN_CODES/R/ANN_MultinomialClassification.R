movie.data<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/movie_data.csv", 
header=TRUE, sep=",")
            
movie.data$gender<- ifelse(movie.data$gender=='M',1,0)
movie.data$member<- ifelse(movie.data$member=='yes',1,0)

movie.data$rating<- ifelse(movie.data$rating=='very bad',1,
ifelse(movie.data$rating=='bad',2,ifelse(movie.data$rating=='okay',3,
ifelse(movie.data$rating=='good',4,5))))

library(neuralnet)

#SCALING VARIABLES TO FALL IN [0,1]
library(dplyr)

scale01 <- function(x){
  (x-min(x))/(max(x)-min(x))
}

movie.data<- movie.data %>% mutate_all(scale01)

#SPLITTING DATA INTO 80% TRAINING AND 20% TESTING SETS 
set.seed(100001)
library(caret)
sample<- createDataPartition(movie.data$rating, p=0.8, list=FALSE)
train<- movie.data[sample,]
test<- movie.data[-sample,]

test.x<- data.matrix(test[-5])
test.y<- data.matrix(test[5])

set.seed(454446)

#FITTING ANN WITH LOGISTIC ACTIVATION FUNCTION
ann.log.mclass<- neuralnet(as.factor(rating) ~ age + gender + member + nmovies,
data=train, hidden=3, act.fct="logistic", stepmax=1e7) 

#PLOTTING THE DIAGRAM
plot(ann.log.mclass)

#COMPUTING PREDICTION ACCURACY FOR TESTING DATA
pred.prob<- predict(ann.log.mclass, test.x)

#computing predicted class
colnames(pred.prob)<- c("0","0.25","0.5","0.75","1")
pred.class<- colnames(pred.prob)[max.col(pred.prob, ties.method="first")]

print(paste("accuracy =", round(mean(pred.class==as.character(test.y)), 4)))

#############################################################

#FITTING ANN WITH TANH ACTIVATION FUNCTION
ann.tanh.mclass<- neuralnet(as.factor(rating) ~ age + gender + member + nmovies,
data=train, hidden=3, act.fct="tanh", stepmax=1e7) 

#PLOTTING THE DIAGRAM
plot(ann.tanh.mclass)

#COMPUTING PREDICTION ACCURACY FOR TESTING DATA
pred.prob<- predict(ann.tanh.mclass, test.x)

#computing predicted class
colnames(pred.prob)<- c("0","0.25","0.5","0.75","1")
pred.class<- colnames(pred.prob)[max.col(pred.prob, ties.method="first")]

print(paste("accuracy =", round(mean(pred.class==as.character(test.y)), 4)))