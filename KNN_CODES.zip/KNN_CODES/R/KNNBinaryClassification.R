pneumonia.data<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/pneumonia_data.csv", 
header=TRUE, sep=",")

pneumonia.data$pneumonia<- ifelse(pneumonia.data$pneumonia=="yes",1,0)

library(caret)

#SPLITTING DATA INTO 80% TRAINING AND 20% TESTING SETS 
set.seed(339601)
sample<- createDataPartition(pneumonia.data$pneumonia, p=0.8, list=FALSE)
train<- pneumonia.data[sample,]
test<- pneumonia.data[-sample,]

#TRAINING K-NEAREST NEIGHBOR BINARY CLASSIFIER -> optimal k=7
print(train(as.factor(pneumonia)~., data=train, method="knn"))

#FITTING OPTIMAL KNN BINARY CLASSIFIER 
knn.biclass<- train(as.factor(pneumonia) ~ ., data = train, method = "knn",
tuneGrid = data.frame(k = 7))

#COMPUTING PREDICTION ACCURACY FOR TESTING DATA 
pred<- predict(knn.biclass, newdata=test)
print(paste("accuracy =", round(mean(pred==as.factor(test$pneumonia)), 4)))