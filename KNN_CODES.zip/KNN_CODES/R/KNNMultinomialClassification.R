movie.data<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/movie_data.csv", 
header=TRUE, sep=",")
            
library(caret)

#SPLITTING DATA INTO 80% TRAINING AND 20% TESTING SETS  
set.seed(566222)

sample<- createDataPartition(movie.data$rating, p=0.8, list=FALSE)
train<- movie.data[sample,]
test<- movie.data[-sample,]

#TRAINING K-NEAREST NEIGHBOR MULTINOMIAL CLASSIFIER -> optimal k=9
print(train(as.factor(rating)~., data=train, method="knn"))

#FITTING OPTIMAL KNN BINARY CLASSIFIER 
knn.mclass<- train(as.factor(rating) ~ ., data = train, method = "knn",
tuneGrid = data.frame(k = 9))

#COMPUTING PREDICTION ACCURACY FOR TESTING DATA 
pred<- predict(knn.mtclass, newdata=test)
print(paste("accuracy =", round(mean(pred==as.factor(test$rating)), 4)))