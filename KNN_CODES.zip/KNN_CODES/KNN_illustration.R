#################################################
#  ILLUTRATION OF K-NEAREST NEIGHBOR REGRESSION #
#################################################
#generating sample data points
set.seed(496002)
x<- runif(40, 0, 6)
y<- runif(40, 0, 6)

#plotting sample data points
plot(x, y, xlim=c(0,6), ylim=c(0,6), xlab="x", ylab="y", 
main="Illustration of k-Nearest Neighbor Regression", pch=16)

#calculating predicted values for grid points
for (grid in seq(0, 6, 0.1)) {
  distance<- c()
  for (z in 1:length(x))
    distance[z]<- abs(grid-x[z])
  min.dist3<- sort(distance)[1:3] # 3 nearest neighbors
  y.pred3<- mean(y[which(distance %in% min.dist3)])
  points(grid,y.pred3,col="red", pch=16)
  
  min.dist5<- sort(distance)[1:5] # 5 nearest neighbors
  y.pred5<- mean(y[which(distance %in% min.dist5)])
  points(grid,y.pred5,col="blue", pch=16)
  
  min.dist7<- sort(distance)[1:7] # 7 nearest neighbors
  y.pred7<- mean(y[which(distance %in% min.dist7)])
  points(grid,y.pred7,col="purple", pch=16)
}
legend("topright",c("k=3","k=5","k=7"),lty=1,lwd=3,col=c("red","blue","purple"),
cex=0.7, text.col=c("red","blue","purple"))

############################################################
#  ILLUTRATION OF K-NEAREST NEIGHBOR BINARY CLASSIFICATION #
############################################################
#generating sample data points
set.seed(300534)

#generating red cluster
red_x<- runif(20, 0.5, 2.5)
red_y<- runif(20, 0.5, 5.5)

#generating blue cluster
blue_x<- runif(20, 3.5, 5.5)
blue_y<- runif(20, 0.5, 5.5)

#generating border mixed-color points
border_x <- runif(10, 2.7, 3.3)
border_y <- runif(10, 0.5, 5.5)
border_color<- sample(c("red", "blue"), 10, replace=TRUE)

#combining points
x<- c(red_x, blue_x, border_x)
y<- c(red_y, blue_y, border_y)
color<- c(rep("red", 20), rep("blue", 20), border_color)

sampledots<- data.frame(x, y, color=color)

#plotting sample data points
plot(sampledots$x, sampledots$y, xlim=c(0,6), ylim=c(0,6), xlab="x",
ylab="y", main="Illustration of k-Nearest Neighbor Binary Classification",
col=sampledots$color, pch=16)

#calculating predicted values for grid points
k<- 5 #five nearest neighbors
for (i in seq(0, 6, 0.1)) {
  for (j in seq(0, 6, 0.1)) {
    distance.sq<- c()
    for (z in 1:length(sampledots$x))
     distance.sq[z]<- (i-sampledots$x[z])^2+(j-sampledots$y[z])^2
    
min.values<- sort(distance.sq)[1:k]
 min.colors<- sampledots$color[which(distance.sq %in% min.values)]
   pred.color<- names(sort(table(min.colors), decreasing=TRUE)[1])
    if (pred.color=="red") col.dot="pink" else col.dot="skyblue"
        points(i,j,col=col.dot, pch=16)
  }
}
points(sampledots$x, sampledots$y, xlim=c(0,6), ylim=c(0,6),
col=sampledots$color, pch=16)

#################################################################
#  ILLUTRATION OF K-NEAREST NEIGHBOR MULTINOMIAL CLASSIFICATION #
#################################################################
#generating sample data points
set.seed(399027)

#generating red cluster
red_x<- runif(20, 0.5, 2.5)
red_y<- runif(20, 0.5, 3.5)

#generating blue cluster
blue_x<- runif(20, 3.5, 5.5)
blue_y<- runif(20, 0.5, 3.5)

#generating green cluster
green_x<- runif(20, 2.0, 4.0)
green_y<- runif(20, 3.5, 5.5)

#generating border mixed-color points
border_x<- runif(10, 2.2, 3.8)
border_y<- runif(10, 2.5, 4.2)
border_color<- sample(c("red", "blue", "darkgreen"), 10, replace=TRUE)

#combining points
x<- c(red_x, blue_x, green_x, border_x)
y<- c(red_y, blue_y, green_y, border_y)
color<- c(rep("red", 20), rep("blue", 20), rep("darkgreen", 20), border_color)

sampledots<- data.frame(x, y, color=color)

#plotting sample data points
plot(sampledots$x, sampledots$y, xlim=c(0,6), ylim=c(0,6), xlab="x",
ylab="y", main="Illustration of k-Nearest Neighbor Multinomial Classification",
col=sampledots$color, pch=16)

#calculating predicted values for grid points
k<- 5 # five nearest neighbors
for (i in seq(0, 6, 0.1)) {
  for (j in seq(0, 6, 0.1)) {
    distance.sq<- c()
    for (z in 1:length(sampledots$x))
      distance.sq[z]<- (i-sampledots$x[z])^2+(j-sampledots$y[z])^2
    min.values<- sort(distance.sq)[1:k]
    min.colors<- sampledots$color[which(distance.sq %in% min.values)]
    15
    pred.color<- names(sort(table(min.colors), decreasing=TRUE)[1])
    if (pred.color=="red") col.dot="pink"
    if (pred.color=="blue") col.dot="skyblue"
    if (pred.color=="darkgreen") col.dot="aquamarine"
    points(i,j,col=col.dot, pch=16)
  }
}
points(sampledots$x, sampledots$y, xlim=c(0,6), ylim=c(0,6),
col=sampledots$color, pch=16)