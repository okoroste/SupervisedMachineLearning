pneumonia.data<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/pneumonia_data.csv", 
header=TRUE, sep=",")

#SPLITTING DATA INTO 80% TRAINING AND 20% TESTING SETS 
set.seed(447558)
library(caret)
sample<- createDataPartition(pneumonia.data$pneumonia, p=0.8, list=FALSE)
train<- pneumonia.data[sample,]
test<- pneumonia.data[-sample,]

#BUILDING RANDOM FOREST BINARY CLASSIFIER
library(randomForest)
rf.class<- randomForest(as.factor(pneumonia) ~ age + gender + tobacco_use	+ PM2_5,
data=train, ntree=150, mtry=4, maxnodes=30)

#DISPLAYING FEATURE IMPORTANCE IN DECREASING ORDER
imp<- importance(rf.class,type=2) 
# sorting in descending order
print(imp[order(imp[,1], decreasing=TRUE),,drop=FALSE])

#COMPUTING PREDICTION ACCURACY FOR TESTING DATA 
predclass<- predict(rf.class, newdata=test)
print(paste("accuracy=", round(mean(predclass == test$pneumonia),4)))
      
#################################################
# COMPUTING PREDICTION METRICS FOR TESTING DATA # 
#################################################

#predicting class with default cut-off of 0.5
predclass<- as.factor(predict(rf.class, newdata=test))
actual<- as.factor(test$pneumonia)

#computing performance measures
TP<- sum(predclass=="yes" & actual=="yes")
TN<- sum(predclass=="no"  & actual=="no")
FP<- sum(predclass=="yes" & actual=="no")
FN<- sum(predclass=="no"  & actual=="yes")

#creating confusion matrix 
conf_matrix<- matrix(c(TP, FN, FP, TN), nrow=2, byrow=TRUE)
rownames(conf_matrix)<- c("Actual: Yes", "Actual: No")
colnames(conf_matrix)<- c("Predicted: Yes", "Predicted: No")
print("Confusion Matrix:")
print(conf_matrix)

accuracy<- (TP+TN)/(TP+TN+FP+FN)
sensitivity<- TP/(TP+FN)
specificity<- TN/(TN+FP)
precision<- TP/(TP+FP)
F1_score<- 2*(precision*sensitivity)/(precision+sensitivity)

print(paste("Accuracy =", round(accuracy,4)))
print(paste("Sensitivity =", round(sensitivity,4)))
print(paste("Specificity =", round(specificity,4)))
print(paste("F1-score =", round(F1_score,4)))

###################################
# PLOTTING ROC AND COMPUTING AUC  #
###################################
library(pROC)

#computing predicted probabilities needed for ROC/AUC
prob_yes<- predict(rf.class, newdata=test, type="prob")[,"yes"]
actual<- factor(test$pneumonia)

#plotting ROC and computing AUC
roc_obj <- roc(actual, prob_yes, levels=c("no","yes"), direction="<")
plot(roc_obj, main=paste("ROC Curve (AUC =", round(as.numeric(auc(roc_obj)), 4), ")"))
abline(a=0, b=1, lty=2)



