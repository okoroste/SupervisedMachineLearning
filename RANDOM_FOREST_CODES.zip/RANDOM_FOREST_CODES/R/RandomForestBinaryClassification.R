pneumonia.data<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/pneumonia_data.csv", 
header=TRUE, sep=",")

#SPLITTING DATA INTO 80% TRAINING AND 20% TESTING SETS 
set.seed(447558)
library(caret)
sample<- createDataPartition(pneumonia.data$pneumonia, p=0.8, list=FALSE)
train<- pneumonia.data[sample,]
test<- pneumonia.data[-sample,]

#BUILDING RANDOM FOREST BINARY CLASSIFIER
library(randomForest)
rf.class<- randomForest(as.factor(pneumonia) ~ age + gender + tobacco_use	+ PM2_5,
data=train, ntree=150, mtry=4, maxnodes=30)

#DISPLAYING FEATURE IMPORTANCE
print(importance(rf.class,type=2)) 

#COMPUTING PREDICTION ACCURACY FOR TESTING DATA 
predclass<- predict(rf.class, newdata=test)
print(paste("accuracy=", round(mean(predclass == test$pneumonia),4)))
      
#####################################################
# COMPUTING PREDICTION PERFORMANCE FOR TESTING DATA # 
#####################################################

library(caret)
library(pROC)

test$pneumonia <- factor(test$pneumonia, levels = c("no","yes"))

pred <- predict(rf.class, test)

cm <- confusionMatrix(pred, test$pneumonia, positive = "yes")
print(cm$table)

prob <- predict(rf.class, test, type="prob")[,"yes"]

roc_obj <- suppressMessages(
  roc(response = test$pneumonia, predictor = prob, levels = c("no","yes"), direction = "<")
)

cat("\nAccuracy:", cm$overall["Accuracy"],
    "\nSensitivity:", cm$byClass["Sensitivity"],
    "\nSpecificity:", cm$byClass["Specificity"],
    "\nF1-score:", cm$byClass["F1"],
    "\nAUC:", as.numeric(auc(roc_obj)), "\n")

plot(roc_obj)

