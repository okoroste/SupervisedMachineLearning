x<- seq(-10,10,by=0.01)
logistic<- exp(x)/(1+exp(x))
tanh<- (exp(x)-exp(-x))/(exp(x)+exp(-x))


plot(x,tanh, type="l", lwd=2, col="blue", panel.first=grid(), 
ylab="f(x)", main="Logistic and Tanh Functions")

lines(x,logistic,type="l", lwd=2, col="green")

legend("bottomright", c("logistic","tanh"), lty=1, lwd=2, col=c("green","blue"))