
#install.packages("keras3")    
#keras3::install_keras()       
#reticulate::py_config()
#install.packages("BiocManager") 
#BiocManager::install("EBImage")
library(keras3)
library(EBImage)



setwd("C:/Users/000110888/OneDrive - CSULB/Desktop/PlayingCardImages/Club") 
img.card<- sample(dir()); 
cards<-list(NULL);        
for(i in 1:length(img.card)) {
 cards[[i]]<- readImage(img.card[i])
   cards[[i]]<- resize(cards[[i]], 100, 100)
}
club<- cards   
#---------------------------------------------------------
setwd("C:/Users/000110888/OneDrive - CSULB/Desktop/PlayingCardImages/Heart")
img.card<- sample(dir());
cards<-list(NULL);
for(i in 1:length(img.card)) { 
  cards[[i]]<- readImage(img.card[i])
    cards[[i]]<- resize(cards[[i]], 100, 100)
}
heart<- cards             
#------------------------------------------------------------
setwd("C:/Users/000110888/OneDrive - CSULB/Desktop/PlayingCardImages/Spade")
img.card<- sample(dir());
cards<-list(NULL);
for(i in 1:length(img.card)) { 
  cards[[i]]<- readImage(img.card[i])
    cards[[i]]<- resize(cards[[i]], 100, 100)
}
spade<- cards             
#------------------------------------------------------------
setwd("C:/Users/000110888/OneDrive - CSULB/Desktop/PlayingCardImages/Diamond")
img.card<- sample(dir());
cards<- list(NULL);
for(i in 1:length(img.card)) { 
  cards[[i]]<- readImage(img.card[i])
    cards[[i]]<- resize(cards[[i]], 100, 100)
}
diamond<- cards   

#splitting into training and testing sets and permuting dimensions
train.pool<- c(club[1:40], heart[1:40], spade[1:40], diamond[1:40])
train.x<- aperm(combine(train.pool), c(4,1,2,3)) 
test.pool<- c(club[41:43], heart[41:43], spade[41:43], diamond[41:43]) 
test.x<- aperm(combine(test.pool), c(4,1,2,3))

#creating image labels
train.y<- c(rep(0,40),rep(1,40),rep(2,40),rep(3,40))
test.y<- c(rep(0,3),rep(1,3),rep(2,3),rep(3,3))
train.lab<- to_categorical(train.y) 
test.lab<- to_categorical(test.y)

#building model
model.card<- keras_model_sequential() 
model.card %>% layer_conv_2d(filters=40, kernel_size=c(4,4),       
activation='relu', input_shape=c(100,100,4)) %>%   
layer_conv_2d(filters=40, kernel_size=c(4,4), activation='relu') %>%  
layer_max_pooling_2d(pool_size=c(4,4))%>% layer_dropout(rate=0.25) %>%   
layer_conv_2d(filters=80, kernel_size=c(4,4), activation='relu') %>%    
layer_conv_2d(filters=80, kernel_size=c(4,4), activation='relu') %>%      
layer_max_pooling_2d(pool_size=c(4,4)) %>% layer_dropout(rate=0.35) %>% 
layer_flatten() %>%  layer_dense(units=256, activation='relu') %>% 
layer_dropout(rate=0.25) %>% layer_dense(units=4, activation="softmax") %>% 
compile(loss='categorical_crossentropy', optimizer=optimizer_adam(),
metrics=c("accuracy"))

history<- model.card %>% fit(train.x, train.lab, epochs=50, batch_size=40,
validation_split=0.2)

#computing prediction accuracy for testing set
model.card %>% evaluate(test.x, test.lab) 
pred.prob<- predict(model.card, test.x)

pred.class<- c()
for (i in 1:nrow(pred.prob))
  pred.class[i]<- which.max(pred.prob[i,])-1

print(pred.class)
print(test.y)

print(paste("accuracy=", round(1-mean(test.y!=pred.class),digits=4)))

