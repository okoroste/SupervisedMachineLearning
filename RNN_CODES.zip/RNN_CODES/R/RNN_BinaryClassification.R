# downloading data from https://finance.yahoo.com/
# install.packages("yahoofinancer")
library(yahoofinancer)

TSLA<- Ticker$new('TSLA')
TSLA.stock<- TSLA$get_history(start='2021-01-26', end='2026-03-26', 
interval='1d')

TSLA.stock$date<- substr(as.POSIXct(strftime(TSLA.stock$date, 
format="%Y-%m-%d %H:%M:%S"), format = "%Y-%m-%d", tz=""), 1, 10)

TSLA.data<- as.data.frame(list(TSLA.stock$date, TSLA.stock$volume),
col.names=c("Date", "Volume"), make.names=FALSE)

tsla.data<- na.omit(TSLA.data)

#computing shocks - 15%+ change in volume
tsla.data.lag<- tsla.data[-1,]
tsla.data<- tsla.data[-nrow(tsla.data),]

shock<- c()
for (i in 1:nrow(tsla.data))
shock[i]<- ifelse(abs(tsla.data.lag[i,2]-tsla.data[i,2])>0.15*tsla.data[i,2],1,0)
tsla.data$Shock<- shock

table(tsla.data$Shock)

#splitting data into testing and training sets
tsla.data$Year<- as.numeric(format(as.Date(tsla.data$Date, format="%Y-%m-%d"),"%Y"))
train.data<- tsla.data[which(tsla.data$Year<2025),1:2]
test.data<- tsla.data[which(tsla.data$Year>=2025),1:2]

nsteps<- 100 #width of sliding window
train.matrix <- matrix(nrow=nrow(train.data)-nsteps, ncol=nsteps+1)
for (i in 1:(nrow(train.data)-nsteps))
  train.matrix[i,]<- tsla.data$Shock[i:(i+nsteps)]

train.x<- array(train.matrix[,-ncol(train.matrix)],dim=c(nrow(train.matrix),nsteps,1))
train.y<- train.matrix[,ncol(train.matrix)]

#creating test.x and test.y
test.matrix<- matrix(nrow=nrow(test.data), ncol=nsteps+1)
for (i in 1:nrow(test.data)) 
  test.matrix[i,]<- tsla.data$Shock[(i+nrow(train.matrix)):(i+nsteps+nrow(train.matrix))]

test.x<- array(test.matrix[,-ncol(test.matrix)],dim=c(nrow(test.matrix),nsteps,1))
test.y<- test.matrix[,ncol(test.matrix)]

##############################################################
#FITTING LSTM MODEL
##############################################################
library(keras3) 
#defining model architecture
LSTM.biclass<- keras_model_sequential()
LSTM.biclass %>% layer_dense(input_shape=dim(train.x)[2:3], units=nsteps)
LSTM.biclass %>% layer_lstm(units=25)
LSTM.biclass %>% layer_dense(units=1, activation="tanh") 
LSTM.biclass %>% compile(loss="binary_crossentropy")

#training model
LSTM.biclass %>% fit(train.x, train.y, batch_size=32, epochs=10)

#computing prediction accuracy for testing data
pred.prob<- LSTM.biclass %>% predict(test.x) 
match<- cbind(test.y, pred.prob)
tp<- matrix(NA, nrow=nrow(match), ncol=99)
tn<- matrix(NA, nrow=nrow(match), ncol=99)

for (i in 1:99) {
  tp[,i]<- ifelse(match[,1]==1 & match[,2]>0.01*i,1,0)
  tn[,i]<- ifelse(match[,1]==0 & match[,2]<=0.01*i,1,0)
}

trueclassrate<- matrix(NA, nrow=99, ncol=2)
for (i in 1:99){
  trueclassrate[i,1]<- 0.01*i
  trueclassrate[i,2]<- sum(tp[,i]+tn[,i])/nrow(match)
}

trueclassrate[which.max(trueclassrate[,2]),]

##############################################################
#FITTING GRU MODEL
##############################################################
#defining model architecture
GRU.biclass<- keras_model_sequential()
GRU.biclass %>% layer_dense(input_shape=dim(train.x)[2:3], units=nsteps)
GRU.biclass %>% layer_gru(units=25)
GRU.biclass %>% layer_dense(units=1, activation="tanh") 
GRU.biclass %>% compile(loss="binary_crossentropy")

#training model
GRU.biclass %>% fit(train.x, train.y, batch_size=32, epochs=5)

#computing prediction accuracy for testing data
pred.prob<- GRU.biclass %>% predict(test.x) 
match<- cbind(test.y, pred.prob)
tp<- matrix(NA, nrow=nrow(match), ncol=99)
tn<- matrix(NA, nrow=nrow(match), ncol=99)

for (i in 1:99) {
  tp[,i]<- ifelse(match[,1]==1 & match[,2]>0.01*i,1,0)
  tn[,i]<- ifelse(match[,1]==0 & match[,2]<=0.01*i,1,0)
}

trueclassrate<- matrix(NA, nrow=99, ncol=2)
for (i in 1:99){
  trueclassrate[i,1]<- 0.01*i
  trueclassrate[i,2]<- sum(tp[,i]+tn[,i])/nrow(match)
}

trueclassrate[which.max(trueclassrate[,2]),]
