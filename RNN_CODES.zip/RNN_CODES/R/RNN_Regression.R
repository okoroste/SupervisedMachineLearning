# downloading data from https://finance.yahoo.com/
# install.packages("yahoofinancer")
library(yahoofinancer)

TSLA<- Ticker$new('TSLA')
TSLA.stock<- TSLA$get_history(start = '2021-01-26', end = '2026-01-26', interval = '1d')

TSLA.stock$date<- substr(as.POSIXct(strftime(TSLA.stock$date, 
format="%Y-%m-%d %H:%M:%S"), format = "%Y-%m-%d", tz=""), 1, 10)

TSLA.data<- as.data.frame(list(TSLA.stock$date, TSLA.stock$close),
col.names=c("Date", "Close"), make.names=FALSE)

tsla.data<- na.omit(TSLA.data)

#splitting data into testing and training sets
tsla.data$Year<- as.numeric(format(as.Date(tsla.data$Date, format="%Y-%m-%d"),"%Y"))

train.data<- tsla.data[which(tsla.data$Year<2025),1:2]
test.data<- tsla.data[which(tsla.data$Year>=2025),1:2]
  
#plotting training and testing data
plot(as.POSIXct(tsla.data$Date), tsla.data$Close, main="Daily Tesla Stock Closing Prices", 
xlab="Time", ylab="Stock Price", pch="", panel.first=grid())
lines(as.POSIXct(train.data$Date), train.data$Close, lwd=2, col="blue")
lines(as.POSIXct(test.data$Date), test.data$Close, lwd=2, col="green")
legend("topleft", c("training", "testing"), lty=1, lwd=2, col=c("blue","green"))

#scaling prices to fall in [0,1]
price<- as.numeric(tsla.data$Close)
price.sc<- (price-min(price))/(max(price)-min(price))

#creating train.x and train.y
nsteps<- 60 #width of sliding window
train.matrix <- matrix(nrow=nrow(train.data)-nsteps, ncol=nsteps+1)
for (i in 1:(nrow(train.data)-nsteps))
  train.matrix[i,]<- price.sc[i:(i+nsteps)]

train.x<- array(train.matrix[,-ncol(train.matrix)],dim=c(nrow(train.matrix),nsteps,1))
train.y<- train.matrix[,ncol(train.matrix)]

#creating test.x and test.y
test.matrix<- matrix(nrow=nrow(test.data), ncol=nsteps+1)
for (i in 1:nrow(test.data)) 
  test.matrix[i,]<- price.sc[(i+nrow(train.matrix)):(i+nsteps+nrow(train.matrix))]

test.x<- array(test.matrix[,-ncol(test.matrix)],dim=c(nrow(test.matrix),nsteps,1))
test.y<- test.matrix[,ncol(test.matrix)]

#################################################
#FITTING LSTM MODEL
##################################################
library(keras3)

LSTM.model <- keras_model_sequential() 

#specifying model structure
LSTM.model %>% layer_lstm(input_shape=dim(train.x)[2:3], units=nsteps)
LSTM.model %>% layer_dense(units=1, activation="tanh") 
LSTM.model %>% compile(loss="mean_squared_error")

#training model
LSTM.model %>% fit(train.x, train.y, batch_size=32, epochs=5)
 
#predicting for testing data
pred.y<- LSTM.model %>% predict(test.x, batch_size=32)

#rescaling test.y and pred.y back to the original scale
test.y.re<- test.y*(max(price)-min(price))+min(price)
pred.y.re<- pred.y*(max(price)-min(price))+min(price)

#computing prediction accuracy
accuracy10<- ifelse(abs(test.y.re-pred.y.re)<0.10*test.y.re,1,0) 
accuracy15<- ifelse(abs(test.y.re-pred.y.re)<0.15*test.y.re,1,0) 
accuracy20<- ifelse(abs(test.y.re-pred.y.re)<0.20*test.y.re,1,0)

print(paste("accuracy within 10%:", round(mean(accuracy10),4)))
print(paste("accuracy within 15%:", round(mean(accuracy15),4)))
print(paste("accuracy within 20%:", round(mean(accuracy20),4)))

#plotting actual and predicted values for testing data
plot(as.POSIXct(test.data$Date), test.y.re, type="l", lwd=2, col="green", 
main="Daily Tesla Stock Actual and Predicted Prices - LSTM Model", 
xlab="Time", ylab="Stock Price", panel.first=grid())
lines(as.POSIXct(test.data$Date), pred.y.re, lwd=2, col="orange")
legend("bottomright", c("actual", "predicted"), lty=1, lwd=2,
col=c("green","orange"))

#################################################
#FITTING GRU MODEL
##################################################
GRU.model <- keras_model_sequential() 

#specifying model structure
GRU.model %>% layer_gru(input_shape=dim(train.x)[2:3], units=nsteps)
GRU.model %>% layer_dense(units=1, activation="tanh") 
GRU.model %>% compile(loss="mean_squared_error")

#training model
GRU.model %>% fit(train.x, train.y, batch_size=32, epochs=5)

#predicting for testing data
pred.y<- GRU.model %>% predict(test.x, batch_size=32)

#rescaling pred.y back to the original scale
pred.y.re<- pred.y*(max(price)-min(price))+min(price)

#computing prediction accuracy
accuracy10<- ifelse(abs(test.y.re-pred.y.re)<0.10*test.y.re,1,0) 
accuracy15<- ifelse(abs(test.y.re-pred.y.re)<0.15*test.y.re,1,0) 
accuracy20<- ifelse(abs(test.y.re-pred.y.re)<0.20*test.y.re,1,0)

print(paste("accuracy within 10%:", round(mean(accuracy10),4)))
print(paste("accuracy within 15%:", round(mean(accuracy15),4)))
print(paste("accuracy within 20%:", round(mean(accuracy20),4)))


#plotting actual and predicted values for testing data
plot(as.POSIXct(test.data$Date), test.y.re, type="l", lwd=2, col="green", 
main="Daily Tesla Stock Actual and Predicted Prices - GRU Model", 
xlab="Time", ylab="Stock Price", panel.first=grid())
lines(as.POSIXct(test.data$Date), pred.y.re, lwd=2, col="orange")
legend("bottomright", c("actual", "predicted"), lty=1, lwd=2,
col=c("green","orange"))

