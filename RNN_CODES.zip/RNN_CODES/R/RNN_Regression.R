# downloading data from https://finance.yahoo.com/
library(yahoofinancer)
library(keras3)

TSLA<- Ticker$new("TSLA")
TSLA.stock<- TSLA$get_history(start="2021-01-26", end="2026-03-25",
interval="1d")

TSLA.stock$date<- substr(as.POSIXct(strftime(TSLA.stock$date, 
format="%Y-%m-%d %H:%M:%S"), format="%Y-%m-%d", tz=""), 1, 10)

TSLA.data<- data.frame(Date=TSLA.stock$date, Close=TSLA.stock$close)

tsla.data<- na.omit(TSLA.data)

#splitting data into training and testing sets
tsla.data$Year<- as.numeric(format(as.Date(tsla.data$Date), "%Y"))

train.data<- tsla.data[tsla.data$Year < 2025, c("Date", "Close")]
test.data<- tsla.data[tsla.data$Year >= 2025, c("Date", "Close")]

#plotting training and testing data
plot(as.POSIXct(tsla.data$Date), tsla.data$Close, main="Daily Tesla 
Stock Closing Prices", xlab="Time", ylab="Stock Price", pch="",
panel.first=grid())
lines(as.POSIXct(train.data$Date), train.data$Close, lwd=2, col="blue")
lines(as.POSIXct(test.data$Date), test.data$Close, lwd=2, col="green")
legend("topleft", c("training", "testing"), lty=1, lwd=2, col=c("blue", 
"green"))

#################################################
# SCALING USING TRAINING DATA ONLY
#################################################
train_min<- min(train.data$Close)
train_max<- max(train.data$Close)

scale_price <- function(x) {
  (x-train_min) / (train_max-train_min)
}

inverse_scale<- function(x_scaled) {
  x_scaled*(train_max-train_min)+train_min
}

#scaling full series using TRAINING min/max
price_all<- as.numeric(tsla.data$Close)
price.sc<- scale_price(price_all)

#################################################
# CREATING TRAIN.X AND TRAIN.Y
#################################################
nsteps<- 60

train_n<- nrow(train.data)
test_n<- nrow(test.data)

train.matrix<- matrix(nrow=train_n-nsteps, ncol=nsteps+1)

for (i in 1:(train_n-nsteps)) {
  train.matrix[i, ]<- price.sc[i:(i+nsteps)]
}

train.x<- array(train.matrix[,-ncol(train.matrix)],
  dim=c(nrow(train.matrix), nsteps, 1))
train.y<- train.matrix[,ncol(train.matrix)]

#################################################
# CREATING TEST.X AND TEST.Y
#################################################
test.matrix<- matrix(nrow=test_n, ncol=nsteps+1)

for (i in 1:test_n) {
  start_idx<- train_n-nsteps+i
  end_idx<- train_n+i
  test.matrix[i,]<- price.sc[start_idx:end_idx]
}

test.x<- array(test.matrix[,-ncol(test.matrix)],
  dim=c(nrow(test.matrix), nsteps, 1))
test.y<- test.matrix[,ncol(test.matrix)]

#converting actual test.y back 
test.y.re<- inverse_scale(test.y)

#################################################
# EVALUATION FUNCTION
#################################################
evaluate_model<- function(pred_scaled, actual_scaled, model_name) {
  pred_orig<- inverse_scale(as.numeric(pred_scaled))
  actual_orig<- inverse_scale(as.numeric(actual_scaled))
  
  acc10<- mean(abs(actual_orig - pred_orig) < 0.10 * actual_orig)
  acc15<- mean(abs(actual_orig - pred_orig) < 0.15 * actual_orig)
  acc20<- mean(abs(actual_orig - pred_orig) < 0.20 * actual_orig)
  
  data.frame(Model=model_name, Accuracy_10=round(acc10, 4),
    Accuracy_15=round(acc15, 4), Accuracy_20=round(acc20, 4))
}

results<- list()

#################################################
# FITTING LSTM MODEL
#################################################
LSTM.model<- keras_model_sequential()

LSTM.model %>% layer_lstm(units=nsteps, input_shape=dim(train.x)[2:3]) %>%
layer_dense(units=1)

LSTM.model %>% compile(loss="mean_squared_error", optimizer="adam")

LSTM.model %>% fit(train.x, train.y, batch_size=32, epochs=5, verbose=1)

pred.lstm<- LSTM.model %>% predict(test.x, batch_size=32)
pred.lstm.re<- inverse_scale(pred.lstm)

results[["LSTM"]]<- evaluate_model(pred.lstm, test.y, "LSTM")

print(results[["LSTM"]])

plot(as.POSIXct(test.data$Date), test.y.re, type="l", lwd=2, col="green",
main="Daily Tesla Stock Actual and Predicted Prices - LSTM Model",
xlab="Time", ylab="Stock Price", panel.first=grid())
lines(as.POSIXct(test.data$Date), pred.lstm.re, lwd=2, col="orange")
legend("bottomright", c("actual", "predicted"), lty=1, lwd=2,
col=c("green", "orange"))

#################################################
# FITTING GRU MODEL
#################################################
GRU.model<- keras_model_sequential()

GRU.model %>% layer_gru(units=nsteps, input_shape=dim(train.x)[2:3]) %>%
layer_dense(units=1, activation="tanh")

GRU.model %>% compile(loss="mean_squared_error", optimizer="adam")

GRU.model %>% fit(train.x, train.y, batch_size=32, epochs=5, verbose=1)

pred.gru<- GRU.model %>% predict(test.x, batch_size=32)
pred.gru.re<- inverse_scale(pred.gru)

results[["GRU"]]<- evaluate_model(pred.gru, test.y, "GRU")

print(results[["GRU"]])

plot(as.POSIXct(test.data$Date), test.y.re, type="l", lwd=2, col="green",
main="Daily Tesla Stock Actual and Predicted Prices - GRU Model",
xlab="Time", ylab="Stock Price", panel.first=grid())
lines(as.POSIXct(test.data$Date), pred.gru.re, lwd=2, col="orange")
legend("bottomright", c("actual", "predicted"), lty=1, lwd=2,
col=c("green", "orange"))

#################################################
# FINAL COMPARISON TABLE
#################################################
final.results<- do.call(rbind, results)
print(final.results)