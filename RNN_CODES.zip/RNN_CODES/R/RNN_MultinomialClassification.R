LA.weather<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/LA_weather.csv", 
header=TRUE, sep=",")

table(LA.weather$Condition)
LA.weather$Rain<- ifelse(LA.weather$Condition=="rain",1, 0)
LA.weather$Fog<- ifelse(LA.weather$Condition=="fog",1, 0)
LA.weather$Clear<- ifelse(LA.weather$Condition=="clear",1,0)
LA.weather$Cloud<- ifelse(LA.weather$Condition=="cloud",1,0)
LA.weather$Year<- format(as.Date(LA.weather$Date, format="%Y-%m-%d"),"%Y")

#DEFINING FUNCTION THAT FITS RNN MODEL 

rnn.model<- function(modelname, varname) {  
  
#creating train.x, train.y, test.x, and test.y sets
train.data<- LA.weather[which(LA.weather$Year<2024),varname]
test.data<- LA.weather[which(LA.weather$Year==2024),varname]

nsteps<- 60 
train.matrix <- matrix(nrow=length(train.data)-nsteps, ncol=nsteps+1)
for (i in 1:(length(train.data)-nsteps))
  train.matrix[i,]<- LA.weather[i:(i+nsteps),varname]

train.x<- array(train.matrix[,-ncol(train.matrix)],dim=c(nrow(train.matrix),nsteps,1))
train.y<- train.matrix[,ncol(train.matrix)]

test.matrix<- matrix(nrow=length(test.data), ncol=nsteps+1)
for (i in 1:length(test.data)) 
  test.matrix[i,]<- LA.weather[(i+nrow(train.matrix)):(i+nsteps+nrow(train.matrix)),varname]

test.x<- array(test.matrix[,-ncol(test.matrix)],dim=c(nrow(test.matrix),nsteps,1))
test.y<- test.matrix[,ncol(test.matrix)]

#defining model architecture
library(keras3)
fitted.model<- keras_model_sequential()
fitted.model %>% layer_dense(input_shape=dim(train.x)[2:3], units=nsteps)
if (modelname=='lstm') {
  fitted.model %>% layer_lstm(units=6)
} else  fitted.model %>% layer_gru(units=6)
fitted.model %>% layer_dense(units=1, activation='sigmoid') 
fitted.model %>% compile(loss='binary_crossentropy')

#training  model
fitted.model %>% fit(train.x, train.y, batch_size=32, epochs=1)

#computing predicted probability of rain for testing data
pred.prob<- fitted.model %>% predict(test.x)
return(list(test.y, pred.prob))

}

#DEFINING FUNCTION THAT COMPUTES PREDICTION ACCURACY
library(dplyr)

accuracy<- function() {
  
test.y<- bind_cols(test.rain, test.fog, test.clear, test.cloud)
colnames(test.y)<- 1:4
true.class<- as.numeric(apply(test.y, 1, function(x) colnames(test.y)[which.max(x)]))
  
pred.prob<- bind_cols(pred.prob.rain, pred.prob.fog, pred.prob.clear, pred.prob.cloud)
colnames(pred.prob)<- 1:4
pred.class<- as.numeric(apply(pred.prob, 1, function(x) colnames(pred.prob)[which.max(x)]))

table(pred.class)
match<- c()
for (i in 1:length(pred.class)) {
  match[i]<- ifelse(pred.class[i]==true.class[i],1,0)
}

return(round(mean(match),4))
}

#RUNNING LSTM BINARY CLASSIFICATION MODELS
list.rain<- (rnn.model('lstm', 'Rain'))
test.rain<- list.rain[1]
pred.prob.rain<- list.rain[2]

list.fog<- rnn.model('lstm', 'Fog')
test.fog<- list.fog[1]
pred.prob.fog<- list.fog[2]

list.clear<- rnn.model('lstm', 'Clear')
test.clear<- list.clear[1]
pred.prob.clear<- list.clear[2]

list.cloud<- rnn.model('lstm', 'Cloud')
test.cloud<- list.cloud[1]
pred.prob.cloud<- list.cloud[2]
print(accuracy())

#RUNNING GRU BINARY CLASSIFICATION MODELS
list.rain<- (rnn.model('gru', 'Rain'))
test.rain<- list.rain[1]
pred.prob.rain<- list.rain[2]

list.fog<- rnn.model('gru', 'Fog')
test.fog<- list.fog[1]
pred.prob.fog<- list.fog[2]

list.clear<- rnn.model('gru', 'Clear')
test.clear<- list.clear[1]
pred.prob.clear<- list.clear[2]

list.cloud<- rnn.model('gru', 'Cloud')
test.cloud<- list.cloud[1]
pred.prob.cloud<- list.cloud[2]
print(accuracy())

