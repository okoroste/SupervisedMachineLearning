#install.packages(c("gutenbergr","stringr","dplyr","tidytext","tibble",
#"ggplot2","wordcloud","stopwords","RColorBrewer"))

library(gutenbergr)
library(dplyr)
library(tidytext)
library(tibble)
library(wordcloud)
library(RColorBrewer)

book<- gutenberg_download(1, mirror="https://mirror.csclub.uwaterloo.ca/gutenberg/",
meta_fields=c("author"))
#1, 12, 46, 74, 1513, 2701, 1232, 2600 

#putting text into tibble format + add row id
book<- as_tibble(book) %>% mutate(document = row_number()) %>% 
select(-gutenberg_id)

#tokenizing the text, counting words, keeping most frequent 
word_counts<- book %>% unnest_tokens(word, text) %>%
count(word, sort=TRUE) %>% filter(n > 1)

#removing stopwords
stop_tbl<- tibble(word=stopwords::stopwords("en"))
word_counts_clean<- anti_join(word_counts, stop_tbl, by="word")

#constructing word cloud
set.seed(366847)
dev.new(width=10, height=10)
suppressWarnings(wordcloud(words=word_counts_clean$word,
freq=word_counts_clean$n, max.words=50,
colors=brewer.pal(8, "Dark2"))) #8=number of colors

#looking for books by author/title
print(gutenberg_works(author=="Shakespeare, William"), n=10)

library(stringr)
gutenberg_metadata %>%  filter(str_detect(title, "Martin Eden"))