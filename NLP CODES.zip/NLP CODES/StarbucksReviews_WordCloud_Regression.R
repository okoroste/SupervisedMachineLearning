library(stringr)
library(dplyr)
library(tidytext)
library(stopwords) 
library(tibble)


reviews<- read.csv("C:/Users/000110888/OneDrive - CSULB/Desktop/StarbucksReviewsData.csv")

#putting text into tibble format (structured table)
reviews <- as_tibble(reviews) %>% 
  mutate(document = row_number())

print(reviews)

#creating tokens
tidy_data <- reviews %>%
  unnest_tokens(word, text) %>%
  group_by(word) %>%
  filter(n() > 10 & nchar(word)>3) %>%
  ungroup()

print(tidy_data)

#identify and removing stopwords
stopword <- as_tibble(stopwords::stopwords("en")) 
stopword <- rename(stopword, word=value)
tb <- anti_join(tidy_data, stopword, by="word")

# replace plural by singular
tb$word<- gsub("customers","customer",tb$word)
tb$word<- gsub("drinks","drink",tb$word)
tb$word<- gsub("baristas","barista",tb$word)

print(tb, n=100)

#plotting word cloud

library(ggplot2)
library(wordcloud)
set.seed(366847)
dev.new(width=10, height=10)
tb %>% count(word) %>% with(wordcloud(word, n,
max.words=50, colors=brewer.pal(8, "Dark2")))

#########################
#  regression modeling  #
#########################

#creating indicator variables for 100 most frequent words
word_list<- tb %>% count(word, sort = TRUE)
word_list<- as.list(word_list[1:100,1])
word_ind<- tb$word %in% word_list$word

tb<- cbind(tb,word_ind)
tb_reduced <- tb[which(tb$word_ind==TRUE),]

dummy_vars <- fastDummies::dummy_cols(tb_reduced$word)
dummy_vars <- dummy_vars[,2:101]
clean_data <- data.frame(cbind(tb_reduced$nstars, dummy_vars))

#fitting cumulative logit regression
library(ordinal)
summary(fitted.model<- clm(as.factor(tb_reduced.nstars) ~ ., 
data=clean_data, link="logit"))



