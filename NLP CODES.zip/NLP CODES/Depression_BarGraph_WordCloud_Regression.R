library(stringr)
library(dplyr)
library(tidytext)
library(stopwords) 
library(tibble)
library(ggplot2)
library(wordcloud)

depression<- read.csv("C:/Users/000110888/OneDrive - CSULB/Desktop/depression_data.csv")

#PUTTING TEXT INTO TIBBLE FORMAT
depression<- as_tibble(depression) %>% mutate(document=row_number())

#CREATING TOKENS
tidy_data<- depression %>% unnest_tokens(word, text) %>%
group_by(word) %>% filter(n() > 10 & nchar(word)>3) %>%
ungroup()

#IDENTIFYING AND REMOVING STOPWORDS
stopword<- as_tibble(stopwords::stopwords("en")) 
stopword<- rename(stopword, word=value)
tb<- anti_join(tidy_data, stopword, by='word')

#CALCULATING WORD FREQUENCY
word_count<- count(tb, word, sort=TRUE)
print(word_count, n=30)

#PLOTTING BAR GRAPH
tb %>% count(word, sort=TRUE) %>% filter(n >800) %>%
  mutate(word=reorder(word, n)) %>% ggplot(aes(word, n)) +
  geom_col(aes()) + xlab(NULL) + scale_y_continuous(expand = c(0, 0)) +
  coord_flip() + theme_classic(base_size = 12) +
  labs(title="Word frequency", subtitle="for top 30 words")+
  theme(plot.title=element_text(lineheight=.8, face="bold")) +
  scale_fill_brewer() 

#PLOTTING WORD CLOUD
set.seed(100485)
dev.new(width=10, height=10)
tb %>% count(word) %>% with(wordcloud(word, n, max.words=30, 
colors=brewer.pal(8, "Dark2")))

#CREATING DUMMIES FOR MOST FREQUENT WORDS
word.list<- tb %>% count(word, sort=TRUE)
word.list<- as.list(word.list[1:30,1])
word_ind<- tb$word %in% word.list$word

tb<- cbind(tb,word_ind)
tb.reduced<- tb[which(tb$word_ind==TRUE),]

dummy.vars<- fastDummies::dummy_cols(tb.reduced$word)
dummy.vars<- dummy.vars[,2:31]
data.clean<- data.frame(cbind(tb.reduced$depression, dummy.vars))

#SPLITTING DATA INTO 90% TRAINING AND 10% TESTING SETS
set.seed(347796)
sample <- sample(c(TRUE, FALSE), nrow(data.clean), replace=TRUE, prob=c(0.9,0.1))
train<- data.clean[sample,]
test<- data.clean[!sample,]

#FITTING BINARY LOGISTIC REGRESSION
train$tb.reduced.depression<- relevel(as.factor(train$tb.reduced.depression),ref="0")
summary(fitted.model<- glm(tb.reduced.depression ~., data=train, 
family=binomial(link=logit)))

#COMPUTING PERFORMANCE MEASURES FOR TESTING DATA
predprob<- predict(fitted.model, newdata=test, type="response")
test<- cbind(test, predprob)

tpos<- matrix(NA, nrow=nrow(test), ncol=102)
fpos<- matrix(NA, nrow=nrow(test), ncol=102)
tneg<- matrix(NA, nrow=nrow(test), ncol=102)
fneg<- matrix(NA, nrow=nrow(test), ncol=102)

for (i in 0:101) {
  tpos[,i+1]<- ifelse(test$tb.reduced.depression=="1" & test$predprob>=0.01*i,1,0)
  fpos[,i+1]<- ifelse(test$tb.reduced.depression=="0" & test$predprob>=0.01*i, 1,0)
  tneg[,i+1]<- ifelse(test$tb.reduced.depression=="0" & test$predprob<0.01*i,1,0)
  fneg[,i+1]<- ifelse(test$tb.reduced.depression=="1" & test$predprob<0.01*i,1,0)
}

tp<- c()
fp<- c()
tn<- c()
fn<- c()
accuracy<- c()
misclassrate<- c()
sensitivity<- c()
specificity<- c()
oneminusspec<- c()
cutoff<- c()

for (i in 1:102) {
  tp[i]<- sum(tpos[,i])
  fp[i]<- sum(fpos[,i])
  tn[i]<- sum(tneg[,i])
  fn[i]<- sum(fneg[,i])
  total<- nrow(test)
  accuracy[i]<- (tp[i]+tn[i])/total
  misclassrate[i]<- (fp[i]+fn[i])/total
  sensitivity[i]<- tp[i]/(tp[i]+fn[i])
  specificity[i]<- tn[i]/(fp[i]+tn[i])
  oneminusspec[i]<- fp[i]/(fp[i]+tn[i])
  cutoff[i]<- 0.01*(i-1)
}

#PLOTTING ROC CURVE
plot(oneminusspec, sensitivity, type="l", lty=1, main="The ROC Curve for Depression Data", 
     xlim=c(0,1), ylim=c(0,1), xlab="1-Specificity", ylab="Sensitivity")
points(oneminusspec, sensitivity, pch=0) 

#REPORTING MEASURES FOR THE POINT ON ROC CURVE CLOSEST TO THE IDEAL POINT (0,1)
distance<- c()
for (i in 1:102)
  distance[i]<- sqrt(oneminusspec[i]^2+(1-sensitivity[i])^2)

measures<- cbind(accuracy, misclassrate, sensitivity, specificity, distance, cutoff)
min.dist<- min(distance)
print(measures[which(measures[,5]==min.dist),])

#COMPUTING AREA UNDER THE ROC CURVE
sensitivity<- sensitivity[order(sensitivity)]
oneminusspec<- oneminusspec[order(oneminusspec)]

library(Hmisc) 
lagx<- Lag(oneminusspec,shift=1)
lagy<- Lag(sensitivity, shift=1)
lagx[is.na(lagx)]<- 0
lagy[is.na(lagy)]<- 0
trapezoid<- (oneminusspec-lagx)*(sensitivity+lagy)/2
print(AUC<- sum(trapezoid))
